

COMO JOGAR:


As teclas  <- (seta para a esquerda) e -> (seta para a direita) controlam as paletas

	 ^
A tecla  |  lança a bolinha 

A tecla HOME pausa o jogo 

A tecla BACKSPACE reinicia o jogo 



O QUE FOI FEITO

- O jogo consegue ser carregado e possui os objetos renderizados em wireframe
- Algumas colisões foram implementadas, as colisões com as paredes.
- A mesa responde a inclinação da mesa, então se no código mudarmos a inclinação da mesa,
  a gravidade vai ter um peso maior ou menor na velocidade da bolinha
- A mesa em si está em um plano 2D, que tem os eixos x e z, quando mudamos a inclinação da mesa a fisica se altera, junto
  com a câmera, mas o mundo 3D não sofre alteração
- A contagem de bolinhas esta sendo realizada, assim como o fim de jogo, após perder-se 3 bolinhas


O QUE FALTOU:

- As texturas não conseguiram ser carregadas
- A fisica do jogo esta incompleta, então não temos algumas colisões
- A pontuação não foi implementada
- O sistema de partículas não foi implementado

	
